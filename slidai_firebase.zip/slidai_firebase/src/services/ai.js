const Anthropic = require('@anthropic-ai/sdk')

let client = null

async function generatePresentation(topic, isPro, style = 'professional') {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error('ANTHROPIC_API_KEY no configurada. Agrégala en Secrets.')
  }
  if (!client) client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

  const max = isPro ? 10 : 4

  const prompt = `Eres experto en storytelling y presentaciones profesionales.
Crea una presentación sobre: "${topic}". Estilo: ${style}. Máximo ${max} slides.

Estructura narrativa:
1. Portada impactante
2. El problema que todos reconocen
3. El insight o dato que cambia todo
4. La solución o propuesta
${isPro ? '5+. Desarrollo, evidencia, cierre con llamada a la acción' : ''}

RESPONDE SOLO CON JSON VÁLIDO. Sin markdown. Sin texto extra:

{
  "title": "Título impactante",
  "theme": "dark",
  "slides": [
    {
      "id": 1,
      "type": "cover",
      "title": "Título del slide (máx 8 palabras)",
      "content": "2-3 oraciones narrativas. Sin bullets.",
      "visual": { "color_accent": "#8b5cf6", "emoji_icon": "🚀", "layout": "centered" },
      "animation": "fade",
      "presenter_note": "Qué decir como expositor. 30-40 palabras.",
      "key_message": "La idea clave en 8 palabras"
    }
  ]
}`

  const msg = await client.messages.create({
    model: 'claude-opus-4-6',
    max_tokens: 4096,
    messages: [{ role: 'user', content: prompt }]
  })

  let text = msg.content[0].text.trim()
  text = text.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim()
  const start = text.indexOf('{')
  if (start > 0) text = text.slice(start)

  const data = JSON.parse(text)
  if (!data.slides?.length) throw new Error('La IA no devolvió slides válidos')

  data.slides = data.slides.map((s, i) => ({
    id: i + 1,
    type:           s.type           || 'insight',
    title:          s.title          || `Slide ${i + 1}`,
    content:        s.content        || '',
    visual: {
      color_accent: s.visual?.color_accent || '#8b5cf6',
      emoji_icon:   s.visual?.emoji_icon   || '✨',
      layout:       s.visual?.layout       || 'centered'
    },
    animation:      s.animation      || 'fade',
    presenter_note: s.presenter_note || '',
    key_message:    s.key_message    || ''
  }))

  if (!['dark','modern','gradient','minimal','neon'].includes(data.theme)) data.theme = 'dark'
  return data
}

module.exports = { generatePresentation }
