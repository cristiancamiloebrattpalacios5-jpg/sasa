const admin = require('firebase-admin')

// Inicializar Firebase solo una vez
if (!admin.apps.length) {
  const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT
    ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)
    : null

  if (!serviceAccount) {
    console.error('❌ FIREBASE_SERVICE_ACCOUNT no configurado en Secrets')
    console.error('   Revisa el README para saber cómo obtenerlo')
  } else {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    })
    console.log('✅ Firebase conectado')
  }
}

const db = admin.apps.length ? admin.firestore() : null

// ── Helpers para no escribir .collection() en cada ruta ──────

const users = {
  async create(data) {
    const ref = db.collection('users').doc()
    const user = { id: ref.id, ...data, is_pro: false, created_at: new Date().toISOString() }
    await ref.set(user)
    return user
  },
  async getById(id) {
    const snap = await db.collection('users').doc(id).get()
    return snap.exists ? { id: snap.id, ...snap.data() } : null
  },
  async getByEmail(email) {
    const snap = await db.collection('users').where('email', '==', email).limit(1).get()
    return snap.empty ? null : { id: snap.docs[0].id, ...snap.docs[0].data() }
  },
  async update(id, data) {
    await db.collection('users').doc(id).update(data)
  }
}

const presentations = {
  async create(data) {
    const ref = db.collection('presentations').doc()
    const p = { id: ref.id, ...data, created_at: new Date().toISOString() }
    await ref.set(p)
    return p
  },
  async listByUser(userId) {
    const snap = await db.collection('presentations')
      .where('user_id', '==', userId)
      .orderBy('created_at', 'desc')
      .get()
    return snap.docs.map(d => ({ id: d.id, ...d.data() }))
  },
  async getById(id) {
    const snap = await db.collection('presentations').doc(id).get()
    return snap.exists ? { id: snap.id, ...snap.data() } : null
  },
  async delete(id) {
    await db.collection('presentations').doc(id).delete()
  },
  async countByUser(userId) {
    const snap = await db.collection('presentations').where('user_id', '==', userId).count().get()
    return snap.data().count
  }
}

module.exports = { users, presentations }
