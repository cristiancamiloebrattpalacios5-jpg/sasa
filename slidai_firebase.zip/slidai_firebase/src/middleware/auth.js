const jwt   = require('jsonwebtoken')
const { users } = require('../db')

const SECRET = () => process.env.JWT_SECRET || 'slidai_dev_secret_2025'

module.exports = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1]
    if (!token) return res.status(401).json({ error: 'Token requerido' })

    const { userId } = jwt.verify(token, SECRET())
    const user = await users.getById(userId)
    if (!user) return res.status(401).json({ error: 'Usuario no encontrado' })

    // Verificar si PRO expiró
    if (user.is_pro && user.pro_expires && new Date(user.pro_expires) < new Date()) {
      await users.update(userId, { is_pro: false })
      user.is_pro = false
    }

    req.user = user
    next()
  } catch {
    res.status(401).json({ error: 'Token inválido' })
  }
}
