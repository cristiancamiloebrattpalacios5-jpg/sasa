const router  = require('express').Router()
const bcrypt  = require('bcryptjs')
const jwt     = require('jsonwebtoken')
const { users } = require('../db')
const authMw  = require('../middleware/auth')

const SECRET  = () => process.env.JWT_SECRET || 'slidai_dev_secret_2025'
const token   = (id) => jwt.sign({ userId: id }, SECRET(), { expiresIn: '30d' })
const safeUser = (u) => ({ id: u.id, email: u.email, name: u.name || null, is_pro: Boolean(u.is_pro) })

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body
  if (!email || !password)      return res.status(400).json({ error: 'Email y contraseña requeridos' })
  if (password.length < 6)      return res.status(400).json({ error: 'Contraseña mínimo 6 caracteres' })

  try {
    const exists = await users.getByEmail(email.toLowerCase())
    if (exists) return res.status(400).json({ error: 'Email ya registrado' })

    const hash = await bcrypt.hash(password, 10)
    const user = await users.create({ email: email.toLowerCase(), password: hash, name: name || null })

    res.status(201).json({ token: token(user.id), user: safeUser(user) })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: e.message })
  }
})

router.post('/login', async (req, res) => {
  const { email, password } = req.body
  if (!email || !password) return res.status(400).json({ error: 'Email y contraseña requeridos' })

  try {
    const user = await users.getByEmail(email.toLowerCase())
    if (!user) return res.status(401).json({ error: 'Credenciales inválidas' })

    const ok = await bcrypt.compare(password, user.password)
    if (!ok) return res.status(401).json({ error: 'Credenciales inválidas' })

    if (user.is_pro && user.pro_expires && new Date(user.pro_expires) < new Date()) {
      await users.update(user.id, { is_pro: false })
      user.is_pro = false
    }

    res.json({ token: token(user.id), user: safeUser(user) })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

router.get('/me', authMw, (req, res) => {
  res.json(safeUser(req.user))
})

module.exports = router
