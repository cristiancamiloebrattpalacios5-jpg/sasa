const router = require('express').Router()
const auth   = require('../middleware/auth')
const { presentations } = require('../db')
const { generatePresentation } = require('../services/ai')

const FREE_LIMIT = 3

router.post('/generate', auth, async (req, res) => {
  const { topic, style } = req.body
  if (!topic?.trim() || topic.trim().length < 3)
    return res.status(400).json({ error: 'Escribe un tema de al menos 3 caracteres' })

  if (!req.user.is_pro) {
    const count = await presentations.countByUser(req.user.id)
    if (count >= FREE_LIMIT) {
      return res.status(403).json({
        error: `Límite del plan gratuito (${FREE_LIMIT} presentaciones)`,
        upgrade_required: true
      })
    }
  }

  try {
    const data = await generatePresentation(topic.trim(), req.user.is_pro, style || 'professional')
    const p = await presentations.create({
      user_id:     req.user.id,
      title:       data.title,
      topic:       topic.trim(),
      slides:      data.slides,
      theme:       data.theme,
      slide_count: data.slides.length
    })
    res.json({ presentation: p })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: e.message || 'Error generando presentación' })
  }
})

router.get('/', auth, async (req, res) => {
  const list = await presentations.listByUser(req.user.id)
  res.json({ presentations: list, count: list.length, limit: req.user.is_pro ? null : FREE_LIMIT })
})

router.get('/:id', auth, async (req, res) => {
  const p = await presentations.getById(req.params.id)
  if (!p || p.user_id !== req.user.id) return res.status(404).json({ error: 'No encontrada' })
  res.json(p)
})

router.delete('/:id', auth, async (req, res) => {
  const p = await presentations.getById(req.params.id)
  if (!p || p.user_id !== req.user.id) return res.status(404).json({ error: 'No encontrada' })
  await presentations.delete(req.params.id)
  res.json({ message: 'Eliminada' })
})

module.exports = router
