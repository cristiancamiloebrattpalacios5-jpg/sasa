const router = require('express').Router()
const auth   = require('../middleware/auth')
const { users } = require('../db')

function getStripe() {
  return require('stripe')(process.env.STRIPE_SECRET_KEY)
}

router.post('/create-checkout', auth, async (req, res) => {
  if (!process.env.STRIPE_SECRET_KEY)
    return res.status(503).json({ error: 'Pagos no configurados. Agrega STRIPE_SECRET_KEY en Secrets.' })

  const stripe  = getStripe()
  const priceId = process.env.STRIPE_PRICE_MONTHLY
  if (!priceId) return res.status(503).json({ error: 'STRIPE_PRICE_MONTHLY no configurado' })

  try {
    let customerId = req.user.stripe_customer_id
    if (!customerId) {
      const cust = await stripe.customers.create({ email: req.user.email, metadata: { userId: req.user.id } })
      customerId = cust.id
      await users.update(req.user.id, { stripe_customer_id: customerId })
    }

    const appUrl = process.env.REPL_URL || 'http://localhost:3000'
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      allow_promotion_codes: true,
      success_url: `${appUrl}/payment/success`,
      cancel_url:  `${appUrl}/pricing`,
      metadata:    { userId: req.user.id }
    })
    res.json({ url: session.url })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

router.post('/cancel', auth, async (req, res) => {
  if (!req.user.stripe_subscription_id)
    return res.status(400).json({ error: 'Sin suscripción activa' })
  const stripe = getStripe()
  await stripe.subscriptions.update(req.user.stripe_subscription_id, { cancel_at_period_end: true })
  res.json({ message: 'Cancelada al final del período' })
})

// Webhook Stripe — raw body configurado en server.js
router.post('/webhook', async (req, res) => {
  if (!process.env.STRIPE_SECRET_KEY) return res.json({ received: true })
  const stripe = getStripe()
  let event
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET)
  } catch (e) {
    return res.status(400).send(`Webhook Error: ${e.message}`)
  }

  try {
    if (event.type === 'checkout.session.completed') {
      const s   = event.data.object
      if (s.mode !== 'subscription') return res.json({ received: true })
      const sub = await stripe.subscriptions.retrieve(s.subscription)
      const exp = new Date(sub.current_period_end * 1000).toISOString()
      await users.update(s.metadata.userId, { is_pro: true, pro_expires: exp, stripe_subscription_id: s.subscription })
      console.log(`✅ PRO activado: ${s.metadata.userId}`)
    }
    if (event.type === 'invoice.payment_succeeded') {
      const inv = event.data.object
      if (!inv.subscription) return res.json({ received: true })
      const sub = await stripe.subscriptions.retrieve(inv.subscription)
      const exp = new Date(sub.current_period_end * 1000).toISOString()
      // Buscar usuario por stripe_subscription_id
      const admin = require('firebase-admin')
      const snap  = await admin.firestore().collection('users').where('stripe_subscription_id','==',inv.subscription).limit(1).get()
      if (!snap.empty) await snap.docs[0].ref.update({ is_pro: true, pro_expires: exp })
    }
    if (event.type === 'customer.subscription.deleted') {
      const admin = require('firebase-admin')
      const snap  = await admin.firestore().collection('users').where('stripe_subscription_id','==',event.data.object.id).limit(1).get()
      if (!snap.empty) await snap.docs[0].ref.update({ is_pro: false, stripe_subscription_id: null })
    }
  } catch (e) { console.error('Webhook error:', e) }

  res.json({ received: true })
})

module.exports = router
