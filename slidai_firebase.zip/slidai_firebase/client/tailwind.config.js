export default {
  content: ['./index.html','./src/**/*.{js,jsx}'],
  theme: {
    extend: {
      animation: {
        fadeIn:   'fadeIn .35s ease-out',
        slideUp:  'slideUp .35s ease-out',
        zoomIn:   'zoomIn .25s ease-out',
        slideLeft:'slideLeft .35s ease-out'
      },
      keyframes: {
        fadeIn:    { from:{ opacity:'0' },                              to:{ opacity:'1' } },
        slideUp:   { from:{ opacity:'0', transform:'translateY(16px)' },to:{ opacity:'1', transform:'translateY(0)' } },
        zoomIn:    { from:{ opacity:'0', transform:'scale(.96)' },      to:{ opacity:'1', transform:'scale(1)' } },
        slideLeft: { from:{ opacity:'0', transform:'translateX(16px)' },to:{ opacity:'1', transform:'translateX(0)' } }
      }
    }
  },
  plugins: []
}
