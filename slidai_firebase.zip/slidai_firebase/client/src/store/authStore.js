import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user:  null,
      token: null,
      setAuth:         (user, token) => set({ user, token }),
      logout:          ()            => set({ user: null, token: null }),
      updateUser:      (p)           => set(s => ({ user: s.user ? { ...s.user, ...p } : null })),
      isPro:           ()            => get().user?.is_pro === true,
      isAuthenticated: ()            => Boolean(get().token && get().user)
    }),
    { name: 'slidai-auth', partialize: s => ({ user: s.user, token: s.token }) }
  )
)
