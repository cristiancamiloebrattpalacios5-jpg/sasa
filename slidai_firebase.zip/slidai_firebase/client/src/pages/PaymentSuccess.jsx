import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle, Loader2, Zap } from 'lucide-react'
import { authAPI } from '../lib/api'
import { useAuthStore } from '../store/authStore'

export default function PaymentSuccess() {
  const [loading, setLoading] = useState(true)
  const updateUser = useAuthStore(s => s.updateUser)

  useEffect(() => {
    const t = setTimeout(async () => {
      try {
        const { data } = await authAPI.me()
        updateUser({ is_pro: data.is_pro })
      } catch {}
      setLoading(false)
    }, 2500)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        {loading ? (
          <><Loader2 size={40} className="animate-spin text-violet-400 mx-auto mb-4"/><p className="text-gray-400">Activando tu plan PRO...</p></>
        ) : (
          <div className="animate-fadeIn">
            <div className="w-20 h-20 bg-violet-600/20 border-2 border-violet-500/40 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={40} className="text-violet-400"/>
            </div>
            <h1 className="text-2xl font-bold mb-2">¡Bienvenido a PRO! 🎉</h1>
            <p className="text-gray-400 mb-8">Tu plan PRO está activo. Presentaciones ilimitadas, hasta 10 slides.</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link to="/generate" className="btn-primary flex items-center justify-center gap-2 py-3 px-6"><Zap size={16}/>Crear presentación PRO</Link>
              <Link to="/dashboard" className="btn-secondary py-3 px-6 text-center">Dashboard</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
