import { useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Check, Zap, Sparkles, Loader2 } from 'lucide-react'
import { paymentsAPI } from '../lib/api'
import { useAuthStore } from '../store/authStore'
import Navbar from '../components/ui/Navbar'

const FREE_F = ['3 presentaciones total','Hasta 4 slides con IA','Modo expositor básico','Todos los temas visuales']
const PRO_F  = ['Presentaciones ilimitadas','Hasta 10 slides con IA','Todos los estilos','Notas avanzadas del presentador','Soporte prioritario']

export default function Pricing() {
  const [loading, setLoading] = useState(false)
  const { user, isPro } = useAuthStore()

  const upgrade = async () => {
    if (!user) { window.location.href='/register'; return }
    setLoading(true)
    try {
      const { data } = await paymentsAPI.createCheckout('monthly')
      window.location.href = data.url
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error al iniciar el pago')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-950">
      <Navbar/>
      <div className="max-w-4xl mx-auto px-4 pt-24 pb-16">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Planes simples</h1>
          <p className="text-gray-400 text-lg">Empieza gratis. Actualiza cuando necesites más.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <div className="card p-7 flex flex-col">
            <h2 className="text-lg font-bold mb-1">Gratuito</h2>
            <p className="text-gray-500 text-sm mb-4">Para explorar</p>
            <div className="flex items-baseline gap-1 mb-6"><span className="text-4xl font-bold">$0</span><span className="text-gray-500">/ siempre</span></div>
            <ul className="space-y-3 mb-8 flex-1">
              {FREE_F.map(f => <li key={f} className="flex items-start gap-2.5 text-sm text-gray-400"><Check size={15} className="text-gray-600 mt-0.5 shrink-0"/>{f}</li>)}
            </ul>
            {user ? <Link to="/dashboard" className="btn-secondary text-center py-3 block">Tu plan actual</Link>
                  : <Link to="/register"  className="btn-secondary text-center py-3 block">Empezar gratis</Link>}
          </div>

          <div className="relative card p-7 flex flex-col border-violet-500/40 bg-violet-600/5">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <span className="text-xs font-bold px-4 py-1 bg-violet-600 text-white rounded-full">MÁS POPULAR</span>
            </div>
            <div className="flex items-center gap-2 mb-1"><h2 className="text-lg font-bold">PRO</h2><Zap size={16} className="text-violet-400"/></div>
            <p className="text-gray-400 text-sm mb-4">Para estudiantes y profesionales</p>
            <div className="flex items-baseline gap-1 mb-6"><span className="text-4xl font-bold">$9</span><span className="text-gray-500">/ mes</span></div>
            <ul className="space-y-3 mb-8 flex-1">
              {PRO_F.map(f => <li key={f} className="flex items-start gap-2.5 text-sm text-gray-300"><Check size={15} className="text-violet-400 mt-0.5 shrink-0"/>{f}</li>)}
            </ul>
            {isPro()
              ? <div className="py-3 text-center text-violet-400 font-semibold flex items-center justify-center gap-2"><Zap size={16}/>Plan PRO activo ✓</div>
              : <button onClick={upgrade} disabled={loading} className="btn-primary py-3.5 text-base w-full flex items-center justify-center gap-2">
                  {loading ? <><Loader2 size={17} className="animate-spin"/>Redirigiendo...</> : <><Sparkles size={17}/>Obtener PRO</>}
                </button>
            }
            <p className="text-center text-xs text-gray-600 mt-3">Pago seguro con Stripe · Cancela cuando quieras</p>
          </div>
        </div>
      </div>
    </div>
  )
}
