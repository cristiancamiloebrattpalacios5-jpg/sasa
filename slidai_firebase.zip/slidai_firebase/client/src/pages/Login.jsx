import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Sparkles, Eye, EyeOff } from 'lucide-react'
import { authAPI } from '../lib/api'
import { useAuthStore } from '../store/authStore'

export default function Login() {
  const [form,    setForm]    = useState({ email:'', password:'' })
  const [loading, setLoading] = useState(false)
  const [showPwd, setShowPwd] = useState(false)
  const navigate = useNavigate()
  const setAuth  = useAuthStore(s => s.setAuth)

  const submit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await authAPI.login(form)
      setAuth(data.user, data.token)
      toast.success('¡Bienvenido!')
      navigate('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error al iniciar sesión')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-2xl font-bold">
            <Sparkles size={24} className="text-violet-400"/>
            <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">SlidAI</span>
          </Link>
          <p className="text-gray-400 mt-2 text-sm">Inicia sesión en tu cuenta</p>
        </div>
        <form onSubmit={submit} className="card p-8 space-y-5">
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Email</label>
            <input type="email" className="input" placeholder="tu@email.com" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} autoFocus/>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Contraseña</label>
            <div className="relative">
              <input type={showPwd?'text':'password'} className="input pr-10" placeholder="••••••••" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))}/>
              <button type="button" onClick={()=>setShowPwd(s=>!s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                {showPwd?<EyeOff size={16}/>:<Eye size={16}/>}
              </button>
            </div>
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">{loading?'Entrando...':'Iniciar sesión'}</button>
          <p className="text-center text-sm text-gray-500">¿No tienes cuenta? <Link to="/register" className="text-violet-400 hover:text-violet-300 font-medium">Regístrate gratis</Link></p>
        </form>
      </div>
    </div>
  )
}
