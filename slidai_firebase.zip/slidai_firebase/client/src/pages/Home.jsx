import { Link } from 'react-router-dom'
import { Sparkles, Zap, Mic, BookOpen, ArrowRight, Star } from 'lucide-react'
import Navbar from '../components/ui/Navbar'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-950">
      <Navbar/>
      <section className="max-w-5xl mx-auto px-4 pt-28 pb-20 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-violet-600/10 border border-violet-500/20 rounded-full text-violet-300 text-sm font-medium mb-6">
          <Sparkles size={13}/> Presentaciones con IA y storytelling real
        </div>
        <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
          <span className="bg-gradient-to-r from-violet-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">Presenta como un experto.</span>
          <br/><span className="text-white">En segundos.</span>
        </h1>
        <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          SlidAI genera presentaciones con narrativa profesional, notas para el expositor y diseño visual único. No es PowerPoint. No es Canva.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link to="/register" className="btn-primary py-3.5 px-8 text-lg flex items-center gap-2 w-full sm:w-auto justify-center">Empezar gratis <ArrowRight size={18}/></Link>
          <Link to="/pricing"  className="btn-secondary py-3.5 px-6 text-base w-full sm:w-auto text-center">Ver precios</Link>
        </div>
        <p className="text-gray-600 text-sm mt-4">Sin tarjeta · 3 presentaciones gratis</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 pb-24">
        <div className="grid md:grid-cols-2 gap-5">
          {[
            { icon:<BookOpen size={20} className="text-violet-400"/>, title:'Storytelling automático', desc:'Estructura dramática: problema → tensión → insight → solución → impacto. No más bullet points aburridos.' },
            { icon:<Mic size={20} className="text-cyan-400"/>,      title:'Modo expositor',          desc:'Notas del presentador generadas por IA. Te dicen qué decir, cuándo pausar y cómo transmitir cada idea.' },
            { icon:<Sparkles size={20} className="text-pink-400"/>, title:'Diseño dinámico único',   desc:'Cada presentación tiene su propio acento visual y paleta. Sin plantillas genéricas.' },
            { icon:<Zap size={20} className="text-yellow-400"/>,    title:'Listo en 20 segundos',    desc:'Escribe el tema, elige el estilo, y en segundos tienes slides listos para presentar.' }
          ].map(f => (
            <div key={f.title} className="card p-6 hover:border-gray-700 transition">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-gray-800 flex items-center justify-center shrink-0">{f.icon}</div>
                <div><h3 className="font-semibold mb-1.5">{f.title}</h3><p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p></div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-2xl mx-auto px-4 pb-24 text-center">
        <div className="flex justify-center gap-1 mb-4">{[1,2,3,4,5].map(i=><Star key={i} size={18} className="text-yellow-400 fill-yellow-400"/>)}</div>
        <blockquote className="text-lg text-gray-300 italic mb-3">"Usé SlidAI para mi tesis y la profesora preguntó qué diseñador contrató. Le dije que fue IA y no me creyó."</blockquote>
        <p className="text-gray-600 text-sm">— Valentina R., estudiante de posgrado</p>
      </section>

      <section className="max-w-3xl mx-auto px-4 pb-24 text-center">
        <div className="card p-10 border-violet-500/20 bg-violet-600/5">
          <h2 className="text-2xl font-bold mb-3">¿Listo para impresionar?</h2>
          <p className="text-gray-400 mb-6">Crea tu primera presentación gratis en menos de 30 segundos</p>
          <Link to="/register" className="btn-primary py-3.5 px-8 text-base inline-flex items-center gap-2"><Sparkles size={16}/>Crear presentación gratis</Link>
        </div>
      </section>

      <footer className="border-t border-gray-800 py-8">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm font-bold">
            <Sparkles size={15} className="text-violet-400"/>
            <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">SlidAI</span>
          </div>
          <p className="text-xs text-gray-700">© 2025 SlidAI. Hecho con IA.</p>
        </div>
      </footer>
    </div>
  )
}
