// Present.jsx
import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Loader2 } from 'lucide-react'
import { presentationsAPI } from '../lib/api'
import PresentationViewer from '../components/viewer/PresentationViewer'

export function Present() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [data, setData] = useState(null)

  useEffect(() => {
    presentationsAPI.get(id)
      .then(({ data }) => setData(data))
      .catch(() => { toast.error('No encontrada'); navigate('/dashboard') })
  }, [id])

  if (!data) return <div className="min-h-screen bg-gray-950 flex items-center justify-center"><Loader2 size={32} className="animate-spin text-violet-400"/></div>
  return <PresentationViewer slides={data.slides} theme={data.theme} onClose={() => navigate('/dashboard')}/>
}

export default Present
