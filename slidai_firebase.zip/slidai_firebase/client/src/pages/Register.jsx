import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Sparkles, Eye, EyeOff, CheckCircle } from 'lucide-react'
import { authAPI } from '../lib/api'
import { useAuthStore } from '../store/authStore'

export default function Register() {
  const [form,    setForm]    = useState({ name:'', email:'', password:'' })
  const [loading, setLoading] = useState(false)
  const [showPwd, setShowPwd] = useState(false)
  const navigate = useNavigate()
  const setAuth  = useAuthStore(s => s.setAuth)

  const submit = async e => {
    e.preventDefault()
    if (form.password.length < 6) return toast.error('Contraseña mínimo 6 caracteres')
    setLoading(true)
    try {
      const { data } = await authAPI.register(form)
      setAuth(data.user, data.token)
      toast.success('¡Cuenta creada! Bienvenido a SlidAI 🚀')
      navigate('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error al registrarse')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-2xl font-bold">
            <Sparkles size={24} className="text-violet-400"/>
            <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">SlidAI</span>
          </Link>
          <p className="text-gray-400 mt-2 text-sm">Crea tu cuenta gratis</p>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-6">
          {['3 presentaciones gratis','IA con storytelling','Modo expositor','Sin tarjeta de crédito'].map(p=>(
            <div key={p} className="flex items-start gap-1.5 text-xs text-gray-400">
              <CheckCircle size={13} className="text-violet-400 mt-0.5 shrink-0"/>{p}
            </div>
          ))}
        </div>
        <form onSubmit={submit} className="card p-8 space-y-5">
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Nombre (opcional)</label>
            <input type="text" className="input" placeholder="Tu nombre" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} autoFocus/>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Email</label>
            <input type="email" className="input" placeholder="tu@email.com" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))}/>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Contraseña</label>
            <div className="relative">
              <input type={showPwd?'text':'password'} className="input pr-10" placeholder="Mínimo 6 caracteres" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))}/>
              <button type="button" onClick={()=>setShowPwd(s=>!s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                {showPwd?<EyeOff size={16}/>:<Eye size={16}/>}
              </button>
            </div>
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3 text-base">{loading?'Creando cuenta...':'Crear cuenta gratis →'}</button>
          <p className="text-center text-sm text-gray-500">¿Ya tienes cuenta? <Link to="/login" className="text-violet-400 hover:text-violet-300 font-medium">Inicia sesión</Link></p>
        </form>
      </div>
    </div>
  )
}
