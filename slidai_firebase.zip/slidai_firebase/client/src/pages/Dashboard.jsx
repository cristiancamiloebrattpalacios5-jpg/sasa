import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Plus, Trash2, Play, Sparkles, Zap, FileText } from 'lucide-react'
import { presentationsAPI } from '../lib/api'
import { useAuthStore } from '../store/authStore'
import Navbar from '../components/ui/Navbar'

export default function Dashboard() {
  const [list,    setList]    = useState([])
  const [loading, setLoading] = useState(true)
  const { user, isPro } = useAuthStore()
  const navigate        = useNavigate()

  useEffect(() => {
    presentationsAPI.list()
      .then(({ data }) => setList(data.presentations))
      .catch(() => toast.error('Error cargando presentaciones'))
      .finally(() => setLoading(false))
  }, [])

  const del = async (id, title) => {
    if (!confirm(`¿Eliminar "${title}"?`)) return
    await presentationsAPI.delete(id)
    setList(l => l.filter(p => p.id !== id))
    toast.success('Eliminada')
  }

  const canCreate = isPro() || list.length < 3

  return (
    <div className="min-h-screen bg-gray-950">
      <Navbar/>
      <div className="max-w-5xl mx-auto px-4 pt-20 pb-16">
        <div className="flex items-start justify-between mb-8 pt-4">
          <div>
            <h1 className="text-xl font-bold mb-1">Dashboard</h1>
            <p className="text-gray-500 text-sm">
              Hola, {user?.name || user?.email?.split('@')[0]} —{' '}
              {isPro()
                ? <span className="text-violet-400 font-medium">Plan PRO activo ✓</span>
                : <span>{list.length}/3 presentaciones usadas</span>
              }
            </p>
          </div>
          {canCreate
            ? <Link to="/generate" className="btn-primary flex items-center gap-2 text-sm"><Plus size={16}/>Nueva</Link>
            : <Link to="/pricing"  className="btn-primary flex items-center gap-2 text-sm"><Zap size={16}/>Mejorar a PRO</Link>
          }
        </div>

        {!isPro() && list.length >= 3 && (
          <div className="mb-6 p-4 rounded-2xl bg-violet-600/10 border border-violet-500/20 flex items-center justify-between gap-4">
            <div>
              <p className="text-violet-300 font-semibold text-sm">Límite del plan gratuito alcanzado</p>
              <p className="text-violet-400/70 text-xs mt-0.5">Actualiza a PRO para presentaciones ilimitadas</p>
            </div>
            <Link to="/pricing" className="btn-primary text-sm py-2 flex items-center gap-1.5"><Zap size={13}/>Ver PRO</Link>
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1,2,3].map(i => <div key={i} className="card h-40 animate-pulse"/>)}
          </div>
        ) : list.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-16 h-16 bg-gray-900 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-gray-800">
              <FileText size={28} className="text-gray-600"/>
            </div>
            <p className="text-gray-400 mb-2">Aún no tienes presentaciones</p>
            <p className="text-gray-600 text-sm mb-6">Crea tu primera con IA en segundos</p>
            <Link to="/generate" className="btn-primary inline-flex items-center gap-2"><Sparkles size={15}/>Crear ahora</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {list.map(p => (
              <div key={p.id} className="card p-5 flex flex-col gap-3 hover:border-gray-700 transition">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wider text-gray-600">{p.theme}</span>
                  <span className="text-xs text-gray-600">{p.slide_count} slides</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm leading-snug line-clamp-2">{p.title}</h3>
                  <p className="text-xs text-gray-600 mt-1">{new Date(p.created_at).toLocaleDateString('es',{day:'numeric',month:'short',year:'numeric'})}</p>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button onClick={()=>navigate(`/present/${p.id}`)} className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium bg-violet-600 hover:bg-violet-500 text-white rounded-lg transition">
                    <Play size={12}/>Presentar
                  </button>
                  <button onClick={()=>del(p.id, p.title)} className="p-2 text-gray-600 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition">
                    <Trash2 size={14}/>
                  </button>
                </div>
              </div>
            ))}
            {canCreate && (
              <Link to="/generate" className="card p-5 flex flex-col items-center justify-center gap-2 border-dashed hover:border-violet-500/40 hover:bg-violet-600/5 transition min-h-[160px]">
                <div className="w-10 h-10 rounded-xl bg-violet-600/20 flex items-center justify-center"><Plus size={20} className="text-violet-400"/></div>
                <span className="text-sm text-gray-500">Nueva presentación</span>
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
