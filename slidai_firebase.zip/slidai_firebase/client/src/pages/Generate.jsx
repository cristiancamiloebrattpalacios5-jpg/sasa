import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { toast } from 'react-hot-toast'
import { Sparkles, ArrowLeft, Loader2, Zap } from 'lucide-react'
import { presentationsAPI } from '../lib/api'
import { useAuthStore } from '../store/authStore'
import Navbar from '../components/ui/Navbar'
import SlideCanvas from '../components/editor/SlideCanvas'

const STYLES = [
  { value:'professional', label:'💼 Profesional', desc:'Negocios, datos' },
  { value:'academic',     label:'🎓 Académico',   desc:'Tesis, clases' },
  { value:'creative',     label:'🎨 Creativo',    desc:'Pitches, ideas' },
  { value:'storytelling', label:'📖 Narrativo',   desc:'Emocional, memorable' }
]

const EXAMPLES = [
  'Cambio climático y sus efectos en las ciudades',
  'Cómo iniciar un negocio con poco dinero',
  'Inteligencia artificial en la educación',
  'Historia de la revolución industrial',
  'Marketing digital para pequeñas empresas',
  'Salud mental en estudiantes universitarios'
]

export default function Generate() {
  const [topic,   setTopic]   = useState('')
  const [style,   setStyle]   = useState('professional')
  const [loading, setLoading] = useState(false)
  const [result,  setResult]  = useState(null)
  const [preview, setPreview] = useState(0)
  const { isPro } = useAuthStore()
  const navigate  = useNavigate()

  const generate = async e => {
    e?.preventDefault()
    if (!topic.trim()) return toast.error('Escribe un tema')
    setLoading(true); setResult(null)
    try {
      const { data } = await presentationsAPI.generate(topic.trim(), style)
      setResult(data.presentation); setPreview(0)
      toast.success(`✨ ${data.presentation.slide_count} slides generados`)
    } catch (err) {
      const e = err.response?.data
      if (e?.upgrade_required) { toast.error('Límite alcanzado. Actualiza a PRO.'); navigate('/pricing') }
      else toast.error(e?.error || 'Error al generar')
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-gray-950">
      <Navbar/>
      <div className="max-w-4xl mx-auto px-4 pt-20 pb-16">
        <div className="flex items-center gap-3 pt-6 mb-8">
          <Link to="/dashboard" className="btn-ghost p-2"><ArrowLeft size={18}/></Link>
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2"><Sparkles size={18} className="text-violet-400"/>Nueva presentación</h1>
            <p className="text-gray-500 text-sm">{isPro() ? 'Plan PRO — hasta 10 slides' : 'Plan gratuito — hasta 4 slides · 3 presentaciones total'}</p>
          </div>
        </div>

        <form onSubmit={generate} className="space-y-5 mb-8">
          <div className="card p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">¿Sobre qué es tu presentación? *</label>
              <textarea className="input resize-none h-28 text-base" placeholder="Ejemplo: Los efectos del cambio climático en la biodiversidad marina..." value={topic} onChange={e=>setTopic(e.target.value)} maxLength={300} autoFocus/>
              <div className="flex justify-between mt-1.5">
                <p className="text-xs text-gray-600">Sé específico para mejores resultados</p>
                <span className="text-xs text-gray-600">{topic.length}/300</span>
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-2">Ejemplos rápidos:</p>
              <div className="flex flex-wrap gap-2">
                {EXAMPLES.map(ex => (
                  <button key={ex} type="button" onClick={()=>setTopic(ex)} className="text-xs px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-white rounded-lg border border-gray-700 transition">{ex}</button>
                ))}
              </div>
            </div>
          </div>

          <div className="card p-5">
            <label className="block text-sm font-medium text-gray-300 mb-3">Estilo</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {STYLES.map(s => (
                <button key={s.value} type="button" onClick={()=>setStyle(s.value)} className={`p-3 rounded-xl border text-left transition ${style===s.value?'border-violet-500 bg-violet-600/10 text-white':'border-gray-700 hover:border-gray-600 text-gray-400'}`}>
                  <div className="text-sm font-medium">{s.label}</div>
                  <div className="text-xs mt-0.5 opacity-60">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>

          <button type="submit" disabled={loading||!topic.trim()} className="btn-primary w-full py-4 text-base flex items-center justify-center gap-3">
            {loading ? <><Loader2 size={18} className="animate-spin"/>Generando con IA... (15-30s)</> : <><Sparkles size={18}/>Generar presentación con IA</>}
          </button>
        </form>

        {result?.slides && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-bold text-lg">{result.title}</h2>
                <p className="text-gray-500 text-sm">{result.slide_count} slides · tema {result.theme}</p>
              </div>
              <button onClick={()=>navigate(`/present/${result.id}`)} className="btn-primary flex items-center gap-2">Presentar →</button>
            </div>
            <SlideCanvas slide={result.slides[preview]} theme={result.theme} showNotes/>
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {result.slides.map((s,i) => (
                <button key={i} onClick={()=>setPreview(i)} className={`rounded-lg overflow-hidden border-2 transition ${preview===i?'border-violet-500':'border-transparent opacity-60 hover:opacity-100'}`}>
                  <SlideCanvas slide={s} theme={result.theme} mini/>
                </button>
              ))}
            </div>
            {!isPro() && (
              <div className="card p-4 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold">¿Quieres más slides?</p>
                  <p className="text-xs text-gray-500 mt-0.5">PRO genera hasta 10 slides y presentaciones ilimitadas</p>
                </div>
                <Link to="/pricing" className="btn-primary text-sm py-2 flex items-center gap-1.5"><Zap size={13}/>Ver PRO</Link>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
