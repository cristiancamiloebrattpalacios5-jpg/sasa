import { Link, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { Sparkles, LogOut, LayoutDashboard, Zap } from 'lucide-react'

export default function Navbar() {
  const { user, logout, isPro } = useAuthStore()
  const navigate = useNavigate()
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-950/90 backdrop-blur border-b border-gray-800">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link to={user ? '/dashboard' : '/'} className="flex items-center gap-2 font-bold text-lg">
          <Sparkles size={20} className="text-violet-400" />
          <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">SlidAI</span>
        </Link>
        <div className="flex items-center gap-2">
          {user ? (
            <>
              {isPro()
                ? <span className="pro-badge"><Zap size={10}/>PRO</span>
                : <Link to="/pricing" className="hidden sm:flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 border border-violet-500/30 rounded-lg transition"><Zap size={12}/>Mejorar a PRO</Link>
              }
              <Link to="/dashboard" className="btn-ghost flex items-center gap-1.5 text-sm"><LayoutDashboard size={15}/><span className="hidden sm:inline">Dashboard</span></Link>
              <button onClick={() => { logout(); navigate('/') }} className="btn-ghost text-sm flex items-center gap-1.5"><LogOut size={15}/><span className="hidden sm:inline">Salir</span></button>
            </>
          ) : (
            <>
              <Link to="/login"    className="btn-ghost text-sm">Entrar</Link>
              <Link to="/register" className="btn-primary text-sm py-2 px-4">Empezar gratis</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
