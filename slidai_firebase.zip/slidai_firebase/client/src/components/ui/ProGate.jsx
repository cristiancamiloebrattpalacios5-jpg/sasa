import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { Lock, Zap } from 'lucide-react'

export default function ProGate({ children, feature = 'esta función' }) {
  const isPro    = useAuthStore(s => s.isPro())
  const navigate = useNavigate()
  if (isPro) return children
  return (
    <div className="relative rounded-2xl overflow-hidden">
      <div className="blur-sm pointer-events-none select-none opacity-50">{children}</div>
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-950/70 backdrop-blur-sm">
        <div className="text-center px-6">
          <div className="w-12 h-12 bg-violet-600/20 border border-violet-500/30 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Lock size={22} className="text-violet-400"/>
          </div>
          <p className="text-white font-semibold mb-1">{feature}</p>
          <p className="text-gray-400 text-sm mb-4">Disponible en el plan PRO</p>
          <button onClick={() => navigate('/pricing')} className="btn-primary flex items-center gap-2 mx-auto text-sm py-2.5">
            <Zap size={14}/> Ver planes PRO
          </button>
        </div>
      </div>
    </div>
  )
}
