const THEMES = {
  dark:     { wrap:'bg-gray-900 text-white',        type:'text-gray-600', title:'text-white',      body:'text-gray-300' },
  modern:   { wrap:'bg-white text-gray-900',         type:'text-gray-400', title:'text-gray-900',   body:'text-gray-600' },
  gradient: { wrap:'bg-gradient-to-br from-violet-950 via-indigo-950 to-gray-950 text-white', type:'text-violet-500', title:'text-white', body:'text-violet-100' },
  minimal:  { wrap:'bg-slate-50 text-slate-900',     type:'text-slate-400', title:'text-slate-900', body:'text-slate-600' },
  neon:     { wrap:'bg-gray-950 text-white',         type:'text-cyan-600',  title:'text-white',     body:'text-cyan-100/80' },
}
const ANIM = { fade:'animate-fadeIn', 'slide-up':'animate-slideUp', zoom:'animate-zoomIn', 'slide-left':'animate-slideLeft', none:'' }

export default function SlideCanvas({ slide, theme='dark', showNotes=false, onClick, mini=false }) {
  const t = THEMES[theme] || THEMES.dark
  if (!slide) return null
  return (
    <div
      onClick={onClick}
      className={`relative slide-aspect w-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl select-none ${t.wrap} ${ANIM[slide.animation]||''} ${onClick?'cursor-pointer hover:scale-[1.01] transition-transform':''}`}
    >
      <div className="absolute left-0 top-0 w-1.5 h-full z-10" style={{backgroundColor: slide.visual?.color_accent||'#8b5cf6'}}/>
      <div className={`absolute top-3 right-3 ${mini?'text-lg':'text-4xl'} opacity-80`}>{slide.visual?.emoji_icon}</div>
      <div className={`absolute top-4 left-6 text-xs uppercase tracking-widest font-medium ${t.type}`}>{slide.type}</div>
      <div className={`flex flex-col justify-center h-full px-10 py-8 gap-3 items-${slide.visual?.layout==='left-aligned'?'start':'center'} text-${slide.visual?.layout==='left-aligned'?'left':'center'}`}>
        <h2 className={`font-bold leading-tight ${t.title} ${mini?'text-sm':'text-2xl md:text-3xl lg:text-4xl'}`}>{slide.title}</h2>
        {slide.content && <p className={`leading-relaxed ${t.body} ${mini?'text-xs line-clamp-2':'text-base max-w-xl'}`}>{slide.content}</p>}
        {slide.key_message && !mini && (
          <div className="mt-1 inline-flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full w-fit"
            style={{backgroundColor:`${slide.visual?.color_accent}22`, color:slide.visual?.color_accent||'#8b5cf6', border:`1px solid ${slide.visual?.color_accent}44`}}>
            💡 {slide.key_message}
          </div>
        )}
      </div>
      {showNotes && slide.presenter_note && !mini && (
        <div className="absolute bottom-0 left-0 right-0 bg-gray-900/90 border-t border-gray-700 text-sm p-3 text-gray-200">
          <span className="text-xs font-semibold uppercase tracking-wider opacity-50 block mb-1">Nota del expositor</span>
          {slide.presenter_note}
        </div>
      )}
      <div className="absolute bottom-3 right-4 text-xs opacity-20 font-mono">{slide.id}</div>
    </div>
  )
}
