import { useState, useEffect, useCallback } from 'react'
import { ChevronLeft, ChevronRight, Mic, X, Eye, EyeOff } from 'lucide-react'
import SlideCanvas from '../editor/SlideCanvas'

export default function PresentationViewer({ slides=[], theme='dark', onClose }) {
  const [cur,      setCur]      = useState(0)
  const [showNotes,setShowNotes] = useState(false)
  const total = slides.length
  const next  = useCallback(() => setCur(i => Math.min(i+1, total-1)), [total])
  const prev  = useCallback(() => setCur(i => Math.max(i-1, 0)), [])

  useEffect(() => {
    const fn = e => {
      if (e.key==='ArrowRight'||e.key===' ') { e.preventDefault(); next() }
      if (e.key==='ArrowLeft')  { e.preventDefault(); prev() }
      if (e.key==='n')          setShowNotes(s=>!s)
      if (e.key==='Escape'&&onClose) onClose()
    }
    window.addEventListener('keydown', fn)
    return () => window.removeEventListener('keydown', fn)
  }, [next, prev, onClose])

  const slide   = slides[cur]
  const percent = total>1 ? ((cur+1)/total)*100 : 100
  if (!slide) return null

  return (
    <div className="flex flex-col h-screen bg-gray-950">
      <div className="h-0.5 bg-gray-800"><div className="h-full bg-violet-500 transition-all duration-300" style={{width:`${percent}%`}}/></div>
      <div className="flex items-center justify-between px-4 py-2 bg-gray-950 border-b border-gray-800">
        <span className="text-gray-400 text-sm font-mono">{cur+1} <span className="text-gray-600">/</span> {total}</span>
        <div className="flex items-center gap-2">
          <button onClick={()=>setShowNotes(s=>!s)} className={`btn-ghost text-xs flex items-center gap-1.5 py-1.5 ${showNotes?'text-violet-400':''}`}>
            <Mic size={13}/> Notas {showNotes?<EyeOff size={11}/>:<Eye size={11}/>}
          </button>
          {onClose && <button onClick={onClose} className="btn-ghost text-gray-400 hover:text-red-400 py-1.5"><X size={16}/></button>}
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-6 md:p-12 overflow-hidden">
        <div className="w-full max-w-5xl">
          <SlideCanvas slide={slide} theme={theme} showNotes={showNotes}/>
        </div>
      </div>
      {showNotes && slide.presenter_note && (
        <div className="bg-gray-900 border-t border-gray-800 px-6 py-4 max-h-44 overflow-auto">
          <p className="text-xs text-violet-400 font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><Mic size={11}/> Guía del expositor</p>
          <p className="text-gray-200 text-sm leading-relaxed">{slide.presenter_note}</p>
        </div>
      )}
      <div className="flex items-center justify-between px-6 py-3 bg-gray-900 border-t border-gray-800">
        <button onClick={prev} disabled={cur===0} className="flex items-center gap-1.5 btn-secondary text-sm py-2 disabled:opacity-30"><ChevronLeft size={16}/>Anterior</button>
        <div className="hidden md:flex items-center gap-1">
          {slides.map((_,i) => (
            <button key={i} onClick={()=>setCur(i)} className={`w-2 h-2 rounded-full transition-all ${i===cur?'bg-violet-500 scale-125':'bg-gray-700 hover:bg-gray-500'}`}/>
          ))}
        </div>
        <button onClick={next} disabled={cur===total-1} className="flex items-center gap-1.5 btn-primary text-sm py-2 disabled:opacity-30">Siguiente<ChevronRight size={16}/></button>
      </div>
      <div className="text-center pb-2 text-xs text-gray-700">← → navegar · N notas · Esc cerrar</div>
    </div>
  )
}
