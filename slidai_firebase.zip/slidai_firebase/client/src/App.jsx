import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAuthStore } from './store/authStore'
import Home           from './pages/Home'
import Login          from './pages/Login'
import Register       from './pages/Register'
import Dashboard      from './pages/Dashboard'
import Generate       from './pages/Generate'
import Present        from './pages/Present'
import Pricing        from './pages/Pricing'
import PaymentSuccess from './pages/PaymentSuccess'

function Private({ children }) {
  return useAuthStore(s => s.isAuthenticated()) ? children : <Navigate to="/login" replace />
}
function PublicOnly({ children }) {
  return !useAuthStore(s => s.isAuthenticated()) ? children : <Navigate to="/dashboard" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{
        style: { background: '#1f2937', color: '#fff', border: '1px solid #374151' }
      }}/>
      <Routes>
        <Route path="/"        element={<Home />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/login"    element={<PublicOnly><Login /></PublicOnly>} />
        <Route path="/register" element={<PublicOnly><Register /></PublicOnly>} />
        <Route path="/dashboard"       element={<Private><Dashboard /></Private>} />
        <Route path="/generate"        element={<Private><Generate /></Private>} />
        <Route path="/present/:id"     element={<Private><Present /></Private>} />
        <Route path="/payment/success" element={<Private><PaymentSuccess /></Private>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
